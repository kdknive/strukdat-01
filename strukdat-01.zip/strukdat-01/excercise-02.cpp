// nama file : excercise-02.cpp
#include <iostream>
using namespace std;

float cel2Fah(float temp){
    float f;
    f = temp * 9/5 + 32;

    return f;
}

int main(){
    int celcius = 9;
    float fahrenheit = cel2Fah(celcius);
    cout<<"temp is "<<fahrenheit;
}
